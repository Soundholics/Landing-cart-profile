package com.example.projectecommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity implements CartActivityAdapter.UserDataInterface {
    CartActivityAdapter recyclerViewAdapter;
    TextView total_price;
    double total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_cart);

        ImageView bt=findViewById(R.id.btn_img_menu);
        bt.setOnClickListener(v->{
            Menu menu=new Menu();
            menu.show(getSupportFragmentManager(),menu.getTag());
        });
        ImageView cart=findViewById(R.id.img_cart_cart);
        cart.setOnClickListener(v->{
            Intent intent=new Intent(this,CartActivity.class);
            startActivity(intent);
        });

        List<Cart> userDataList = new ArrayList<>();
        total=generateUserData(userDataList);
        RecyclerView recyclerView = findViewById(R.id.cart_recycler);
         recyclerViewAdapter= new CartActivityAdapter(userDataList, CartActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recyclerViewAdapter);
        TextView address=findViewById(R.id.ed_address_cart);
        address.setEnabled(false);
        total_price=findViewById(R.id.tv_total_cart);
        total_price.setText(String.format("Total: Rs %s", String.valueOf(total)));
        findViewById(R.id.bt_change_address_cart).setOnClickListener(v->{
            address.setEnabled(true);
        });
        findViewById(R.id.bt_check_out_cart).setOnClickListener(v->{
            address.setEnabled(false);
            if(address.getText().equals(null))
                Toast.makeText(this,"Please add address!",Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this,"Order Placed!",Toast.LENGTH_SHORT).show();

        });
    }

    @Override
    public void onPlusClick(Cart cartData, CartActivityAdapter.ViewHolder holder) {
        holder.itemView.findViewById(R.id.img_minus_cart).setOnClickListener(view ->
                { int v = Integer.parseInt(holder.getTvQuan().getText().toString());
                    v++;
                    holder.getTvQuan().setText(String.valueOf(v));
                    holder.getTvPrice().setText(String.format("Rs %s", (cartData.getPrice() * v)));
                    total_price=findViewById(R.id.tv_total_cart);
                    total+=cartData.getPrice();
                    total_price.setText(String.format("Total: Rs %s", total));
                }
        );

    }
    @Override
    public void onMinusClick(Cart cartData1, CartActivityAdapter.ViewHolder holder1) {
        holder1.itemView.findViewById(R.id.img_plus_cart).setOnClickListener(view ->
                {
                    int v = Integer.parseInt(holder1.getTvQuan().getText().toString());
                    v--;
                    holder1.getTvQuan().setText(String.valueOf(v));
                    holder1.getTvPrice().setText(String.format("Rs %s", (cartData1.getPrice() * v)));
                    total_price=findViewById(R.id.tv_total_cart);
                    total-=cartData1.getPrice();
                    total_price.setText(String.format("Total: Rs %s", total));
                }
        );

    }

    @Override
    public void onUserClick(Cart userData) {
        Toast.makeText(this, "Image Clicked for" + userData.getName(), Toast.LENGTH_SHORT).show();
    }

    private double generateUserData(List<Cart> userDataList) {
        double total=0;
        userDataList.add(new Cart("Product 1", 1000.0,0));
        userDataList.add(new Cart("Product 2", 1000.0,0));
        userDataList.add(new Cart("Product 3", 1050.0,0));
        userDataList.add(new Cart("Product 4", 200000.0,0));
        userDataList.add(new Cart("Product 5", 10090.0,0));
        userDataList.add(new Cart("Product 6", 10500.5,0));
        userDataList.add(new Cart("Product 7", 1060.0,0));
        userDataList.add(new Cart("Product 8", 10089.0,0));
        userDataList.add(new Cart("Product 9", 100670.0,0));
        userDataList.add(new Cart("Product 10", 100.0,0));
        for(int i=0;i<userDataList.size();i++){
            total+=userDataList.get(i).getPrice()*userDataList.get(i).getQuantity();
        }
        return total;
    }
}
