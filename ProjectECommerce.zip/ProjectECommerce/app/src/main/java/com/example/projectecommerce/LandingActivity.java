package com.example.projectecommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.SearchView;

import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class LandingActivity extends AppCompatActivity implements LandingActivityAdapter.UserDataInterface, LandingActivityAdapter2.UserDataInterface, LandingActivityAdapter3.UserDataInterface{
    LandingActivityAdapter recyclerViewAdapter;
    LandingActivityAdapter2 recyclerViewAdapter2;
    LandingActivityAdapter3 recyclerViewAdapter3;
    ImageView audioPlayer, earBuds, inEar, wirelessHeadphones,wirelessSpeaker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_landing);

        ImageView bt=findViewById(R.id.btn_img_menu);
        bt.setOnClickListener(v->{
            Menu menu=new Menu();
            menu.show(getSupportFragmentManager(),menu.getTag());
        });

        ImageView cart=findViewById(R.id.img_cart_cart);
        cart.setOnClickListener(v->{
            Intent intent=new Intent(this,CartActivity.class);
            startActivity(intent);
        });

        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnClickListener(v -> searchView.setIconified(false));

        audioPlayer=findViewById(R.id.ic_audioplayer);
        earBuds=findViewById(R.id.ic_buds);
        inEar=findViewById(R.id.ic_inEar);
        wirelessHeadphones=findViewById(R.id.ic_wirelessHeadphone);
        wirelessSpeaker=findViewById(R.id.ic_speaker);

        audioPlayer.setOnClickListener(v->{
            Toast.makeText(this,"AudioPlayer",Toast.LENGTH_SHORT).show();
        });

        earBuds.setOnClickListener(v->{
            Toast.makeText(this,"EarBuds",Toast.LENGTH_SHORT).show();
        });

        inEar.setOnClickListener(v->{
            Toast.makeText(this,"InEar",Toast.LENGTH_SHORT).show();
        });
        wirelessSpeaker.setOnClickListener(v->{
            Toast.makeText(this,"WirelessSpeaker",Toast.LENGTH_SHORT).show();
        });
        wirelessHeadphones.setOnClickListener(v->{
            Toast.makeText(this,"WirelessHeadphones",Toast.LENGTH_SHORT).show();
        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener(){

            @Override
            public boolean onQueryTextSubmit(String query) {

                Toast.makeText(LandingActivity.this,query,Toast.LENGTH_SHORT).show();
                closeKeyboard();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });



        List<Landing> userDataList2 = new ArrayList<>();
        generateUserData2(userDataList2);
        RecyclerView recyclerView2 = findViewById(R.id.land_recycle2);
        recyclerViewAdapter2= new LandingActivityAdapter2(userDataList2, LandingActivity.this);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView2.setAdapter(recyclerViewAdapter2);

        List<Landing> userDataList = new ArrayList<>();
        generateUserData(userDataList);
        RecyclerView recyclerView = findViewById(R.id.land_recycle1);
        recyclerViewAdapter= new LandingActivityAdapter(userDataList, LandingActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(recyclerViewAdapter);

        List<Landing> userDataList3 = new ArrayList<>();
        generateUserData3(userDataList3);
        RecyclerView recyclerView3 = findViewById(R.id.land_recycle3);
        recyclerViewAdapter3= new LandingActivityAdapter3(userDataList, LandingActivity.this);
        recyclerView3.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView3.setAdapter(recyclerViewAdapter3);

    }
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void onUserClick(Landing userData) {
        Toast.makeText(this, "Image Clicked for" + userData.getName(), Toast.LENGTH_SHORT).show();
    }
    private void generateUserData(List<Landing> userDataList) {
        userDataList.add(new Landing("Product 1", 1000.0));
        userDataList.add(new Landing("Product 2", 1000.0));
        userDataList.add(new Landing("Product 3", 1050.0));
        userDataList.add(new Landing("Product 4", 200000.0));
        userDataList.add(new Landing("Product 5", 10090.0));
    }
    private void generateUserData2(List<Landing> userDataList) {
        userDataList.add(new Landing("Product 1", 1000.0));
        userDataList.add(new Landing("Product 2", 1000.0));
        userDataList.add(new Landing("Product 3", 1050.0));
        userDataList.add(new Landing("Product 4", 200000.0));
        userDataList.add(new Landing("Product 5", 10090.0));
    }
    private void generateUserData3(List<Landing> userDataList) {
        userDataList.add(new Landing("Product 1", 1000.0));
        userDataList.add(new Landing("Product 2", 1000.0));
        userDataList.add(new Landing("Product 3", 1050.0));
        userDataList.add(new Landing("Product 4", 200000.0));
        userDataList.add(new Landing("Product 5", 10090.0));
    }
}