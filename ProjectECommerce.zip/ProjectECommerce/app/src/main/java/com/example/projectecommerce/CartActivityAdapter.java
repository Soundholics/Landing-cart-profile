package com.example.projectecommerce;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartActivityAdapter extends RecyclerView.Adapter<CartActivityAdapter.ViewHolder>{
    private final List<Cart> mUserDataList;
    private final UserDataInterface mUserDataInterface;
    public CartActivityAdapter(List<Cart> userDataList, UserDataInterface mUserDataInterface) {
        this.mUserDataList = userDataList;
        this.mUserDataInterface = mUserDataInterface;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_entity, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cart userData = mUserDataList.get(position);
        holder.tvName.setText(userData.getName());
        holder.tvQuan.setText(String.valueOf(userData.getQuantity()));
        holder.tvPrice.setText(String.format("Rs %s", String.valueOf(userData.getPrice())));
        holder.rootView.setOnClickListener((view -> mUserDataInterface.onUserClick(userData)));

        holder.rootView.findViewById(R.id.img_minus_cart).setOnClickListener(view -> mUserDataInterface.onPlusClick(userData,holder));
        holder.rootView.findViewById(R.id.img_plus_cart).setOnClickListener(view -> mUserDataInterface.onMinusClick(userData,holder));

    }
    @Override
    public int getItemCount() {
        return mUserDataList.size();
    }

    public interface UserDataInterface {
        void onUserClick(Cart cartData);
        void onPlusClick(Cart cartData,ViewHolder holder);
        void onMinusClick(Cart cartData, ViewHolder holder);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvName;
        private final View rootView;
        private final TextView tvPrice;
        private final TextView tvQuan;

        public ViewHolder(View view) {
            super(view);
            rootView = view;
            tvName = view.findViewById(R.id.tv_name_cart);
            tvPrice=view.findViewById(R.id.tv_price_cart);
            tvQuan=view.findViewById(R.id.qty_cart);
        }

        public TextView getTvName() {
            return tvName;
        }

        public View getRootView() {
            return rootView;
        }

        public TextView getTvPrice() {
            return tvPrice;
        }

        public TextView getTvQuan() {
            return tvQuan;
        }
    }
}
