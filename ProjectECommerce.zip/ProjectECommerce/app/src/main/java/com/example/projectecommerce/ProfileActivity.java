package com.example.projectecommerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_profile);

        ImageView bt=findViewById(R.id.btn_img_menu_profile);
        bt.setOnClickListener(v->{
            Menu menu=new Menu();
            menu.show(getSupportFragmentManager(),menu.getTag());
        });

        ImageView cart=findViewById(R.id.img_cart_cart);
        cart.setOnClickListener(v->{
            Intent intent=new Intent(this,CartActivity.class);
            startActivity(intent);
        });

        EditText tvName=findViewById(R.id.name_profile);
        EditText tvEmail=findViewById(R.id.email_profile);
        EditText tvAdd=findViewById(R.id.add_profile);
        EditText tvPhone=findViewById(R.id.phone_profile);
        Button savebt=findViewById(R.id.save_bt_profile);
        tvName.setEnabled(false);
        tvPhone.setEnabled(false);
        tvEmail.setEnabled(false);
        tvAdd.setEnabled(false);
        findViewById(R.id.edit_bt_profile).setOnClickListener(v->{
            tvName.setEnabled(true);
            tvAdd.setEnabled(true);
            tvEmail.setEnabled(true);
            tvAdd.setEnabled(true);
            savebt.setVisibility(View.VISIBLE);

        });
        savebt.setOnClickListener(v->{
            tvName.setEnabled(false);
            tvPhone.setEnabled(false);
            tvEmail.setEnabled(false);
            tvAdd.setEnabled(false);
            Toast.makeText(this,"Saved!",Toast.LENGTH_SHORT).show();
        });
    }
}