package com.example.projectecommerce;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LandingActivityAdapter extends RecyclerView.Adapter<LandingActivityAdapter.ViewHolder>{

    private final List<Landing> mUserDataList;
    private final LandingActivityAdapter.UserDataInterface mUserDataInterface;
    public LandingActivityAdapter(List<Landing> userDataList, LandingActivityAdapter.UserDataInterface mUserDataInterface) {
        this.mUserDataList = userDataList;
        this.mUserDataInterface = mUserDataInterface;
    }
    @NonNull
    @Override
    public LandingActivityAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cat1, parent, false);
        return new LandingActivityAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LandingActivityAdapter.ViewHolder holder, int position) {
        Landing userData = mUserDataList.get(position);
        holder.tvName.setText(userData.getName());
        holder.tvPrice.setText(String.format("Rs %s", String.valueOf(userData.getPrice())));
        holder.rootView.setOnClickListener((view -> mUserDataInterface.onUserClick(userData)));

    }

    @Override
    public int getItemCount() {
        return mUserDataList.size();
    }

    public interface UserDataInterface {
        void onUserClick(Landing cartData);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvName;
        private final View rootView;
        private final TextView tvPrice;

        public ViewHolder(View view) {
            super(view);
            rootView = view;
            tvName = view.findViewById(R.id.tv_name_land1);
            tvPrice=view.findViewById(R.id.tv_price_land1);
        }

        public TextView getTvName() {
            return tvName;
        }

        public View getRootView() {
            return rootView;
        }

        public TextView getTvPrice() {
            return tvPrice;
        }
    }
}
